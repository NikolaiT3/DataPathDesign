//Program 1, file name "lab5_prob3_1.c"
#include <stdio.h>
int main(int argc, char *argv[])
{
	printf("Hello, world\n");
	return 0;
}
