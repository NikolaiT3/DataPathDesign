//File 2, named "lab5_prob5_print.c"
#include <stdio.h>
void print_hello(){
	printf("Hello, world\n");
};
