//File 1, named "lab5_prob5_main.c"
void print_hello();
int main(int argc, char *argv[])
{
	print_hello();
	return 0;
}
