//Program 2, file name "lab5_prob3_2.c"
#include <stdio.h>
int main(int argc, char *argv[])
{
	int i = 1;
	i++;
	printf("The value of  i is %d\n", i);
	return 0;
}
